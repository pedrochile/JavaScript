const shoppingCart = []
const carro = (productId)=>{
    const cartContainter = document.getElementById(`product-container`)
    const showProductsInCart = () =>{

        let productos = cartProducts.find(products => product.id ==productId)
        shoppingCart.push(productos)
        //agregar el localStorage dfespuessssss
    
        let div = document.createElement(`div`)
        div.classList.add


    }
}








